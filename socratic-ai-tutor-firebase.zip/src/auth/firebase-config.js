// Firebase Configuration for Socratic AI
export const firebaseConfig = {
    apiKey: "AIzaSyDTn4TXLQCQHvtU_fwk-8lZd-6Nx5Udj7M",
    authDomain: "socratic-ai-82849.firebaseapp.com",
    projectId: "socratic-ai-82849",
    storageBucket: "socratic-ai-82849.firebasestorage.app",
    messagingSenderId: "528705306538",
    appId: "1:528705306538:web:2982f568ec05ee08a575d3",
    measurementId: "G-2WGBW7GXSG"
};
